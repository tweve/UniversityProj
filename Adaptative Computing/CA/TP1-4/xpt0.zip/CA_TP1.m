
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computacao Adaptatiiva - O perceptr�o
% Professor Ant�nio Dourado
%
% Daniel Frutuoso - 2009109673
% Igor Nelson Garrido da Cruz - 2009111924
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fig = 1;
% AND -------------------
inputAND = [0 0; 0 1; 1 0; 1 1];
targetAND = [0, 0, 0, 1];
weightAND = rand(1,2);
weightBiasAND = 0;

% OR --------------------
inputOR = [0 0; 0 1; 1 0; 1 1];
targetOR = [0, 1, 1, 1];
weightOR = rand(1,2);
weightBiasOR = 0;

% XOR -------------------
inputXOR = [0 0; 0 1; 1 0; 1 1];
targetXOR = [0, 1, 1, 0];
weightXOR =  rand(1,2);
weightBiasXOR = 0;

% treina perceptrao para funcao AND -------------
errados = 1;
it = 0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Treino Funcao AND
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while(errados>0)
    % se o n�mero de iteracoes for maior do que 10 o programa desiste 
       if (it > 10)
        break;
       end

    errados = 0;
    it= it+1;

    % desenha a fronteira de decisao
    x=-0.5:0.01:1.5;
    y = -( weightAND(1)/weightAND(2))*x - weightBiasAND/weightAND(2);
    figure(fig)
    fig= fig+1;
    hold off
    plot(x,y,'green','LineWidth',4);
    axis([-0.5 1.5 -0.5 1.5])
    legend('fronteira de decisao')
    hold on
    
    % decide como marcar os pontos no grafico ? asterisco ou bola ?
    if (-( weightAND(1)/weightAND(2))*0 - weightBiasAND/weightAND(2)> 0)
        plot(0,0,'o','MarkerSize',14);
    else
        plot(0,0,'*red','MarkerSize',14)
    end
    
     if (-( weightAND(1)/weightAND(2))*0 - weightBiasAND/weightAND(2)> 1)
        plot(0,1,'o','MarkerSize',14);
    else
        plot(0,1,'*red','MarkerSize',14)
    end
    if (-( weightAND(1)/weightAND(2))*1 - weightBiasAND/weightAND(2)> 0)
        plot(1,0,'o','MarkerSize',14);
    else
        plot(1,0,'*red','MarkerSize',14)
    end
    
     if (-( weightAND(1)/weightAND(2))*1 - weightBiasAND/weightAND(2)> 1)
        plot(1,1,'o','MarkerSize',14);
    else
        plot(1,1,'*red','MarkerSize',14);
     end
     % desenha label no grafico com o numero de iteracoes
     s = strcat('Perceptrao AND : Iteracao  ', int2str(it));
     xlabel(s,'fontsize',12,'fontweight','b','color','b');
    
    % treina o perceptrao            
    for i = 1:length(inputAND)
            a = ( inputAND(i,1) * weightAND(1) )+ (inputAND(i,2) * weightAND(2) ) + weightBiasAND ;
           
            if (a>=0)
                a = 1;
            else
                a = 0;
            end
            
            e = targetAND(i) - a;

            if (e ~= 0)
                 weightAND = weightAND + e*(inputAND(i,:));
                 weightBiasAND = weightBiasAND + e;
                 errados = errados + 1;
            end
         
    end
end

% disp('activation AND');
% 
%  for i = 1:length(inputAND)
% 
% 
%     a = ( inputAND(i,1) * weightAND(1) + inputAND(i,2) * weightAND(2) ) + weightBiasAND;
%     if (a>=0)
%         a = 1
%     else
%         a = 0
%     end
%  end
%  
 
 
 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Treino funcao OR
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
 
 errados = 1;
 it = 0;
 
 while(errados>0)
    % se o n�mero de iteracoes for maior do que 10 o programa desiste 
    if (it > 10)
    break;
    end
    
    errados = 0;
    it= it+1;

    % desenha a fronteira de decisao

    x=-0.5:0.01:1.5;
    y = -( weightOR(1)/weightOR(2))*x - weightBiasOR/weightOR(2);
    figure(fig)
    fig = fig+1;
    hold off
    plot(x,y,'green','LineWidth',4);
    axis([-0.5 1.5 -0.5 1.5])
    legend('fronteira de decisao')
    hold on
    
    
    % decide como marcar os pontos no grafico ? asterisco ou bola ?

    if (-( weightOR(1)/weightOR(2))*0 - weightBiasOR/weightOR(2)> 0)
        plot(0,0,'o','MarkerSize',14);
    else
        plot(0,0,'*red','MarkerSize',14)
    end
    
     if (-( weightOR(1)/weightOR(2))*0 - weightBiasOR/weightOR(2)> 1)
        plot(0,1,'o','MarkerSize',14);
    else
        plot(0,1,'*red','MarkerSize',14)
    end
    if (-( weightOR(1)/weightOR(2))*1 - weightBiasOR/weightOR(2)> 0)
        plot(1,0,'o','MarkerSize',14);
    else
        plot(1,0,'*red','MarkerSize',14)
    end
    
     if (-( weightOR(1)/weightOR(2))*1 - weightBiasOR/weightOR(2)> 1)
        plot(1,1,'o','MarkerSize',14);
    else
        plot(1,1,'*red','MarkerSize',14);
     end
     
     s = strcat('Perceptrao OR: Iteracao  ', int2str(it));
     xlabel(s,'fontsize',12,'fontweight','b','color','b');
    
     
    % treina o perceptrao para a funcao OR
    for i = 1:length(inputOR)
            a = ( inputOR(i,1) * weightOR(1) )+ (inputOR(i,2) * weightOR(2) ) + weightBiasOR ;
           
            if (a>=0)
                a = 1;
            else
                a = 0;
            end
            
            e = targetOR(i) - a;

            if (e ~= 0)
                 weightOR = weightOR + e*(inputOR(i,:));
                 weightBiasOR = weightBiasOR + e;
                 errados = errados + 1;
            end
         
    end
end

disp('activation OR');

 for i = 1:length(inputOR)


    a = ( inputOR(i,1) * weightOR(1) + inputOR(i,2) * weightOR(2) ) + weightBiasOR;
    if (a>=0)
        a = 1
    else
        a = 0
    end
 end
 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Treino para funcao XOR
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 
 errados = 1;
 it = 0;
 
 while(errados>0)
     
    % Se o n�mero de iteracoes for superior a 10 o programa desiste  
    if (it > 10)
        break;
    end
    
    errados = 0;
    it= it+1;

    % Desenha a fronteira de decisao
    x=-0.5:0.01:1.5;
    y = -( weightXOR(1)/weightXOR(2))*x - weightBiasXOR/weightXOR(2);
     figure(fig)
    fig = fig+1;
    hold off
    plot(x,y,'green','LineWidth',4);
    axis([-0.5 1.5 -0.5 1.5])
    legend('fronteira de decisao')
    hold on
    
    % Decide como marcar os potos nas entradas 
    if (-( weightXOR(1)/weightXOR(2))*0 - weightBiasXOR/weightXOR(2)> 0)
        plot(0,0,'o','MarkerSize',14);
    else
        plot(0,0,'*red','MarkerSize',14)
    end
    
     if (-( weightXOR(1)/weightXOR(2))*0 - weightBiasXOR/weightXOR(2)> 1)
        plot(0,1,'o','MarkerSize',14);
    else
        plot(0,1,'*red','MarkerSize',14)
    end
    if (-( weightXOR(1)/weightXOR(2))*1 - weightBiasXOR/weightXOR(2)> 0)
        plot(1,0,'o','MarkerSize',14);
    else
        plot(1,0,'*red','MarkerSize',14)
    end
    
     if (-( weightXOR(1)/weightXOR(2))*1 - weightBiasXOR/weightXOR(2)> 1)
        plot(1,1,'o','MarkerSize',14);
    else
        plot(1,1,'*red','MarkerSize',14);
     end
     
     s = strcat('Perceptrao XOR: Iteracao  ', int2str(it));
     xlabel(s,'fontsize',12,'fontweight','b','color','b');
    
     
    % tenta treinar o perceptrao para a funcao XOR
    for i = 1:length(inputXOR)
            a = ( inputXOR(i,1) * weightXOR(1) )+ (inputXOR(i,2) * weightXOR(2) ) + weightBiasXOR ;
           
            if (a>=0)
                a = 1;
            else
                a = 0;
            end
            
            e = targetXOR(i) - a;

            if (e ~= 0)
                 weightXOR = weightXOR + e*(inputXOR(i,:));
                 weightBiasXOR = weightBiasXOR + e;
                 errados = errados + 1;
            end
         
    end
 end

 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Rede neuronal para funcao XOR
% necessitamos de treinar um nand e usar o OR e o AND criados anteriomente
% para fazer um AND(NAND OR) das entrasdas
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NAND -------------------
inputNAND = [0 0; 0 1; 1 0; 1 1];
targetNAND = [1, 1, 1, 0];
weightNAND =  rand(1,2);
weightBiasNAND = 0;

inputNNXOR = [0 0; 0 1; 1 0; 1 1];
targetNNXOR = [1, 1, 1, 0];

errados = 1;
it = 0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% 
% Treino de funcao NAND
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while(errados>0)
    
       if (it > 10)
        break;
       end

    errados = 0;
    it= it+1;     
           
    for i = 1:length(inputNAND)
            a = ( inputNAND(i,1) * weightNAND(1) )+ (inputNAND(i,2) * weightNAND(2) ) + weightBiasNAND ;
           
            if (a>=0)
                a = 1;
            else
                a = 0;
            end
            
            e = targetNAND(i) - a;

            if (e ~= 0)
                 weightNAND = weightNAND + e*(inputNAND(i,:));
                 weightBiasNAND = weightBiasNAND + e;
                 errados = errados + 1;
            end
         
    end
end
 x=-0.5:0.01:1.5;
    y = -( weightNAND(1)/weightNAND(2))*x - weightBiasNAND/weightNAND(2);
    figure(fig)
    fig = fig+1;
    hold off
    plot(x,y,'green','LineWidth',4);
    axis([-0.5 1.5 -0.5 1.5])
    legend('fronteira de decisao')
    hold on
    
    
    
    x=-0.5:0.01:1.5;
    y = -( weightOR(1)/weightOR(2))*x - weightBiasOR/weightOR(2);


    plot(x,y,'yellow','LineWidth',4);
    axis([-0.5 1.5 -0.5 1.5])
 
    legend('fronteira de decisao')

    
    
    if (-( weightNAND(1)/weightNAND(2))*0 - weightBiasNAND/weightNAND(2)< 0 )
        if (-( weightOR(1)/weightOR(2))*0 - weightBiasOR/weightOR(2)> 0 )
          plot(0,0,'*red','MarkerSize',14)
        else
            plot(0,0,'o','MarkerSize',14);
        end
    else
        if (-( weightOR(1)/weightOR(2))*0 - weightBiasOR/weightOR(2)> 0 )
          plot(0,0,'o','MarkerSize',14);
        else
            plot(0,0,'*red','MarkerSize',14)
        end
    end
    
     if (-( weightNAND(1)/weightNAND(2))*0 - weightBiasNAND/weightNAND(2)< 1)
        plot(0,1,'o','MarkerSize',14);
    else
        plot(0,1,'*red','MarkerSize',14)
    end
    if (-( weightNAND(1)/weightNAND(2))*1 - weightBiasNAND/weightNAND(2)< 0)
        plot(1,0,'o','MarkerSize',14);
    else
        plot(1,0,'*red','MarkerSize',14)
    end
    
     if (-( weightNAND(1)/weightNAND(2))*1 - weightBiasNAND/weightNAND(2)< 1)
        plot(1,1,'o','MarkerSize',14);
    else
        plot(1,1,'*red','MarkerSize',14);
     end
     
     s = strcat('Rede Neuronal XOR: Iteracao  ', int2str(it));
     xlabel(s,'fontsize',12,'fontweight','b','color','b');
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% C�lculo de outputs de rede neuronal para o XOR feito a custa de um and 
% (or e nand)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% disp('activation XOR');
% 
%  for i = 1:length(inputNAND)
% 
%     aOR = ( inputOR(i,1) * weightOR(1) + inputOR(i,2) * weightOR(2) ) + weightBiasOR;
%     if (aOR>=0)
%         aOR = 1;
%     else
%         aOR = 0;
%     end
%     
%     aNAND = ( inputNAND(i,1) * weightNAND(1) + inputNAND(i,2) * weightNAND(2) ) + weightBiasNAND;
%     if (aNAND>=0)
%         aNAND = 1;
%     else
%         aNAND = 0;
%     end
%     
%      aAND = ( aOR * weightAND(1) + aNAND* weightAND(2) ) + weightBiasAND;
%     if (aAND>=0)
%         aAND = 1
%     else
%         aAND = 0
%     end
%     
%  end
 
 
